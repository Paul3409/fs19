SirenSignals = {}
SirenSignals.instances = {}
SirenSignals.activePlaceable = nil

SirenSignals.DEFINITIONS = {
    { action = "SIREN_PROBE",       text = "input_SIREN_PROBE",       sample = "probe",    duration = 25.50 },
    { action = "SIREN_ALARM",       text = "input_SIREN_ALARM",       sample = "alarm",    duration = 63.50 },
    { action = "SIREN_WARNING",     text = "input_SIREN_WARNING",     sample = "warning",  duration = 68.00 },
    { action = "SIREN_ALLCLEAR",    text = "input_SIREN_ALLCLEAR",    sample = "allclear", duration = 70.10 }
}

function SirenSignals.registerEventListeners(placeableType)
    SpecializationUtil.registerEventListener(placeableType, "onLoad", SirenSignals)
    SpecializationUtil.registerEventListener(placeableType, "onDelete", SirenSignals)
    SpecializationUtil.registerEventListener(placeableType, "onUpdate", SirenSignals)
    SpecializationUtil.registerEventListener(placeableType, "onWriteStream", SirenSignals)
    SpecializationUtil.registerEventListener(placeableType, "onReadStream", SirenSignals)
end

function SirenSignals:onLoad(savegame)
    local spec = { samples = {}, actionEvents = {}, activeSignal = 0, startedAt = 0 }
    self.spec_sirenSignals = spec

    if self.isClient then
        for i, definition in ipairs(SirenSignals.DEFINITIONS) do
            spec.samples[i] = g_soundManager:loadSampleFromXML(
                self.xmlFile,
                "placeable.sirenSignals",
                definition.sample,
                self.baseDirectory,
                self.nodeId,
                1,
                AudioGroup.ENVIRONMENT,
                nil,
                nil
            )
        end
    end

    SirenSignals.instances[self] = true
end

function SirenSignals:getPlayerDistanceSquared(player)
    if self.nodeId == nil or self.nodeId == 0 or player == nil or player.rootNode == nil then
        return math.huge
    end

    local x, _, z = getWorldTranslation(self.nodeId)
    local px, _, pz = getWorldTranslation(player.rootNode)
    local dx, dz = px - x, pz - z
    return dx * dx + dz * dz
end

function SirenSignals:getNearestPlaceableInRange()
    local mission = g_currentMission
    local player = mission ~= nil and mission.player or nil
    if player == nil then
        return nil
    end

    local nearest, nearestDistance = nil, 12 * 12
    for placeable in pairs(SirenSignals.instances) do
        if placeable.spec_sirenSignals ~= nil and placeable.isClient and not placeable.isDeleted then
            local distance = SirenSignals.getPlayerDistanceSquared(placeable, player)
            if distance < nearestDistance then
                nearest, nearestDistance = placeable, distance
            end
        end
    end
    return nearest
end

function SirenSignals:removeActionEvents()
    local spec = self.spec_sirenSignals
    if spec == nil or #spec.actionEvents == 0 then
        return
    end
    -- These actions are registered in the player input context. Remove them
    -- there as well, then restore any player bindings that were temporarily
    -- suppressed because they use the same number keys.
    g_inputBinding:resetActiveActionBindings()
    g_inputBinding:beginActionEventsModification(Player.INPUT_CONTEXT_NAME)
    for _, eventId in ipairs(spec.actionEvents) do
        g_inputBinding:removeActionEvent(eventId)
    end
    g_inputBinding:endActionEventsModification()
    spec.actionEvents = {}
end

function SirenSignals:registerActionEvents()
    local spec = self.spec_sirenSignals
    if spec == nil or not self.isClient or #spec.actionEvents > 0 then
        return
    end

    -- Number keys are already used by several on-foot actions. Register in
    -- the player context with conflict removal so all four signals can be
    -- selected while standing by the siren; the normal bindings are restored
    -- as soon as the player walks away.
    g_inputBinding:beginActionEventsModification(Player.INPUT_CONTEXT_NAME)
    for i, definition in ipairs(SirenSignals.DEFINITIONS) do
        local success, eventId = g_inputBinding:registerActionEvent(
            definition.action,
            self,
            SirenSignals.onInput,
            false,
            true,
            false,
            true,
            { signal = i },
            true
        )
        if success and eventId ~= nil then
            table.insert(spec.actionEvents, eventId)
            g_inputBinding:setActionEventText(eventId, g_i18n:getText(definition.text, self.customEnvironment))
            g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_NORMAL)
            g_inputBinding:setActionEventTextVisibility(eventId, true)
        end
    end
    g_inputBinding:endActionEventsModification()
end

function SirenSignals.onInput(placeable, actionName, inputValue, callbackState)
    if callbackState ~= nil and callbackState.signal ~= nil then
        SirenSignals.requestSignal(placeable, callbackState.signal)
    end
end

function SirenSignals.requestSignal(placeable, signalIndex)
    if placeable == nil or placeable.spec_sirenSignals == nil then
        return
    end

    if placeable.isServer then
        local activeSignal = placeable.spec_sirenSignals.activeSignal
        local requestedSignal = activeSignal == signalIndex and 0 or signalIndex
        SirenSignals.setSignal(placeable, requestedSignal)
        if g_server ~= nil then
            g_server:broadcastEvent(SirenSignalEvent.new(placeable, requestedSignal), nil, nil, placeable)
        end
    elseif g_client ~= nil and g_client:getServerConnection() ~= nil then
        g_client:getServerConnection():sendEvent(SirenSignalEvent.new(placeable, signalIndex))
    end
end

function SirenSignals.setSignal(placeable, signalIndex)
    local spec = placeable.spec_sirenSignals
    if spec == nil then
        return
    end

    if spec.activeSignal ~= 0 and spec.samples[spec.activeSignal] ~= nil then
        g_soundManager:stopSample(spec.samples[spec.activeSignal])
    end

    spec.activeSignal = signalIndex
    spec.startedAt = g_currentMission ~= nil and g_currentMission.time or 0

    if signalIndex > 0 and spec.samples[signalIndex] ~= nil then
        g_soundManager:playSample(spec.samples[signalIndex])
    end
end

function SirenSignals:onUpdate(dt)
    local spec = self.spec_sirenSignals
    if spec == nil then
        return
    end

    if spec.activeSignal > 0 then
        local definition = SirenSignals.DEFINITIONS[spec.activeSignal]
        if definition ~= nil and g_currentMission.time - spec.startedAt >= definition.duration * 1000 then
            spec.activeSignal = 0
        end
    end

    if self.isClient then
        local nearest = SirenSignals.getNearestPlaceableInRange()
        if nearest == self then
            SirenSignals.activePlaceable = self
            self:registerActionEvents()
        else
            self:removeActionEvents()
            if SirenSignals.activePlaceable == self then
                SirenSignals.activePlaceable = nearest
            end
        end
    end
end

function SirenSignals:onWriteStream(streamId, connection)
    streamWriteInt8(streamId, self.spec_sirenSignals.activeSignal)
end

function SirenSignals:onReadStream(streamId, connection)
    local signalIndex = streamReadInt8(streamId)
    if signalIndex > 0 then
        SirenSignals.setSignal(self, signalIndex)
    end
end

function SirenSignals:onDelete()
    local spec = self.spec_sirenSignals
    SirenSignals.instances[self] = nil
    self:removeActionEvents()
    if SirenSignals.activePlaceable == self then
        SirenSignals.activePlaceable = nil
    end

    if spec ~= nil then
        for _, sample in pairs(spec.samples) do
            if sample ~= nil then
                g_soundManager:stopSample(sample)
                g_soundManager:deleteSample(sample)
            end
        end
    end
end

SirenSignalEvent = {}
local SirenSignalEvent_mt = Class(SirenSignalEvent, Event)
InitEventClass(SirenSignalEvent, "SirenSignalEvent")

function SirenSignalEvent.emptyNew()
    return Event.new(SirenSignalEvent_mt)
end

function SirenSignalEvent.new(placeable, signalIndex)
    local self = SirenSignalEvent.emptyNew()
    self.placeable = placeable
    self.signalIndex = signalIndex
    return self
end

function SirenSignalEvent:readStream(streamId, connection)
    self.placeable = networkGetObject(streamReadInt32(streamId))
    self.signalIndex = streamReadInt8(streamId)
    self:run(connection)
end

function SirenSignalEvent:writeStream(streamId, connection)
    streamWriteInt32(streamId, networkGetObjectId(self.placeable))
    streamWriteInt8(streamId, self.signalIndex)
end

function SirenSignalEvent:run(connection)
    if self.placeable == nil then
        return
    end
    if connection ~= nil and not connection:getIsServer() then
        local activeSignal = self.placeable.spec_sirenSignals.activeSignal
        local requestedSignal = activeSignal == self.signalIndex and 0 or self.signalIndex
        SirenSignals.setSignal(self.placeable, requestedSignal)
        if g_server ~= nil then
            g_server:broadcastEvent(SirenSignalEvent.new(self.placeable, requestedSignal), nil, connection, self.placeable)
        end
    else
        SirenSignals.setSignal(self.placeable, self.signalIndex)
    end
end
