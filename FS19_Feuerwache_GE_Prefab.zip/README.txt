Feuerwache GE Prefab – FS19 / GE 8.2.2

Öffne feuerwache.i3d im GIANTS Editor 8.2.2. Dieses Paket basiert auf der FS19-konvertierten I3D, nicht auf der FS22-Fassung. Externe Bildtexturen wurden soweit möglich durch lokale, vereinfachte Wachen-Texturen ersetzt.

Die Tor-/Tür-Gruppen und Kollisionsknoten bleiben im Scenegraph. Wähle die Torgruppe bzw. den vorhandenen unsichtbaren col-Knoten aus, um die Collision im GE zu bearbeiten.

Die $data/shaders-Verweise sind GIANTS-Shader aus FS19 und benötigen die FS19-Dateninstallation für vollständige Materialdarstellung.
