EmergencyControls = {}

function EmergencyControls.prerequisitesPresent(specializations)
    return SpecializationUtil.hasSpecialization(Drivable, specializations)
end

function EmergencyControls.registerEventListeners(vehicleType)
    SpecializationUtil.registerEventListener(vehicleType, "onLoad", EmergencyControls)
    SpecializationUtil.registerEventListener(vehicleType, "onDelete", EmergencyControls)
    SpecializationUtil.registerEventListener(vehicleType, "onRegisterActionEvents", EmergencyControls)
end

function EmergencyControls:onLoad(savegame)
    self.spec_emergencyControls = {actionEvents = {}, hornPlaying = false, rearWarning = false}
    if self.isClient then
        local spec = self.spec_emergencyControls
        spec.hornSample = g_soundManager:loadSampleFromXML(self.xmlFile, "vehicle.emergencyControls", "horn", self.baseDirectory, self.components, 0, AudioGroup.VEHICLE, self.i3dMappings, self)
    end
end

function EmergencyControls:onRegisterActionEvents(isActiveForInput, isActiveForInputIgnoreSelection)
    local spec = self.spec_emergencyControls
    self:clearActionEventsTable(spec.actionEvents)
    if not self.isClient or not isActiveForInputIgnoreSelection then return end
    local _, f = self:addActionEvent(spec.actionEvents, InputAction.MAN_EPSA_BEACON, self, EmergencyControls.actionEvent, false, true, false, true)
    local _, r = self:addActionEvent(spec.actionEvents, InputAction.MAN_EPSA_HORN, self, EmergencyControls.actionEvent, false, true, false, true)
    local _, x = self:addActionEvent(spec.actionEvents, InputAction.MAN_EPSA_REAR, self, EmergencyControls.actionEvent, false, true, false, true)
    if f then g_inputBinding:setActionEventText(f, g_i18n:getText("action_MAN_EPSA_BEACON")) end
    if r then g_inputBinding:setActionEventText(r, g_i18n:getText("action_MAN_EPSA_HORN")) end
    if x then g_inputBinding:setActionEventText(x, g_i18n:getText("action_MAN_EPSA_REAR")) end
end

function EmergencyControls.actionEvent(self, actionName)
    local spec = self.spec_emergencyControls
    if actionName == InputAction.MAN_EPSA_BEACON then
        self:setBeaconLightsVisibility(not self:getIsBeaconLightsActive())
    elseif actionName == InputAction.MAN_EPSA_HORN and spec.hornSample ~= nil then
        if spec.hornPlaying then g_soundManager:stopSample(spec.hornSample) else g_soundManager:playSample(spec.hornSample) end
        spec.hornPlaying = not spec.hornPlaying
    elseif actionName == InputAction.MAN_EPSA_REAR then
        spec.rearWarning = not spec.rearWarning
    end
end

function EmergencyControls:onUpdate(dt)
    local spec = self.spec_emergencyControls
    if spec.rearWarning then
        local visible = math.floor(g_currentMission.time / 140) % 2 == 0
        if self.spec_lights ~= nil and self.spec_lights.lightNodes ~= nil then
            for _, node in ipairs(self.spec_lights.lightNodes) do
                if node ~= nil and node.lightType == 2 then setVisibility(node.node, visible) end
            end
        end
    end
end

function EmergencyControls:onDelete()
    local spec = self.spec_emergencyControls
    if spec ~= nil and spec.hornSample ~= nil then
        g_soundManager:stopSample(spec.hornSample)
        g_soundManager:deleteSample(spec.hornSample)
    end
end
