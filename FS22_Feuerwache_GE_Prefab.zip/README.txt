FS22 Feuerwache – GE Prefab mit vereinfachten Texturen

Die Texturverweise auf $data-Bilddateien wurden durch lokale, mitgelieferte Wachen-Texturen ersetzt. Dadurch ist das I3D nicht mehr auf die FS22-Bilddateien angewiesen. Einige Oberflächen/Details sehen dadurch vereinheitlicht aus; dies sind bewusst einfache Ersatztexturen.

Öffne feuerwache.i3d im Giants Editor. Die Tore und Türen sind im Szenegraph weiterhin als einzelne Teile/Gruppen vorhanden und können dort ausgewählt und mit Collision bearbeitet werden.

Hinweis: Shader-Verweise auf $data/shaders bleiben erhalten. GIANTS Editor benötigt passende GIANTS-Shader; diese sind keine Bildtexturen und lassen sich nicht durch eine DDS-Datei ersetzen.
